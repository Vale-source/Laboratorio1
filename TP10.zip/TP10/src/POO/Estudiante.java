package POO;

public class Estudiante {

    private String nombre;
    private int edad, identificacion;

    public Estudiante(){
        nombre = "Juan Cruz";
        edad = 18;
        identificacion = 122421;
    }
}
