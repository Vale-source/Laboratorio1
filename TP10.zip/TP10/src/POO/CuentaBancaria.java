package POO;

public class CuentaBancaria {

    private double saldo;
    private int nrocuenta;

    public CuentaBancaria(){
        saldo = 0;
        nrocuenta = 12345;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }


    public double getSaldo() {
        return saldo;
    }

    public int getNrocuenta() {
        return nrocuenta;
    }
}
