package POO;

public class Coche {
    private String marca, modelo;
    private int año_fabricacion, velocidad;

    public Coche() {
        marca = "Fiat";
        modelo = "Palio";
        año_fabricacion = 2015;
        velocidad = 0;
    }

    public void acelerar(int incrementoVelocidad) {
        this.velocidad += incrementoVelocidad;
        System.out.println("El coche aceleró. Velocidad actual: " + this.velocidad + " km/h");
    }

    public void frenar(int decrementoVelocidad) {
        this.velocidad -= decrementoVelocidad;

        if (this.velocidad < 0) {
            this.velocidad = 0;
        }

        System.out.println("El coche frenó. Velocidad actual: " + this.velocidad + " km/h");
    }

}
