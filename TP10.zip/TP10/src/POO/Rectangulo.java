package POO;

public class Rectangulo {
    private double ancho, largo;

    public Rectangulo(){
        ancho = 0;
        largo = 0;
    }

    public double getAncho() {
        return ancho;
    }

    public void setAncho(double ancho) {
        this.ancho = ancho;
    }

    public double getLargo() {
        return largo;
    }

    public void setLargo(double largo) {
        this.largo = largo;
    }

    public static double area(double largo, double ancho){
        return largo*ancho;
    }

    public static double perimetro(double largo, double ancho){
        return (largo*2) + (ancho*2);
    }
}
