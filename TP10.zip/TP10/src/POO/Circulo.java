package POO;

public class Circulo {
    private double radio;

    public Circulo(){
        radio = 0;
    }

    public static double area(double radio){
        return Math.round(Math.PI * (Math.pow(radio, 2)));
    }

    public static double perimetro(double radio){
        return Math.round(2 * Math.PI * radio);
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }


}
