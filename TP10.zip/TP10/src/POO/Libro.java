package POO;

public class Libro {
    private String titulo, autor;
    private int año_publicacion;

    public Libro(){
        titulo = "El Señor de los Anillos: El Retorno del Rey";
        autor = "J.R.R Tolkien";
        año_publicacion = 1955;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public int getAño_publicacion() {
        return año_publicacion;
    }
}
