package POO;

public class Pelicula {

    private String titulo, director;
    private int minutos;

    public Pelicula(){
        titulo = "El Hobbit: Un viaje inesperado";
        director = "Peter Jackson";
        minutos = 169;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDirector() {
        return director;
    }

    public int getMinutos() {
        return minutos;
    }
}
