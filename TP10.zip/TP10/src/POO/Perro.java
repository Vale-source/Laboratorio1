package POO;

public class Perro {
    private String nombre;
    private String raza;
    private int edad;


    public Perro(){
        nombre = "Pipo";
        raza = "Beagle";
        edad = 6;
    }
    public static String ladrar(){
        return "Guau, guau";
    }
}
