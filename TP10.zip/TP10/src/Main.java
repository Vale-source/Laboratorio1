import POO.*;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Circulo circulo = new Circulo();
        Scanner sc = new Scanner(System.in);
        Libro lb = new Libro();
        CuentaBancaria CB = new CuentaBancaria();
        Rectangulo R = new Rectangulo();
        Coche auto = new Coche();
        Pelicula P = new Pelicula();

        System.out.print("Ingrese el radio del circulo: ");
        double radio = sc.nextDouble();
        circulo.setRadio(radio);
        System.out.println(circulo.getRadio());
        System.out.println("El area del circulo ingresado es: "+ Circulo.area(radio));
        System.out.println("El perimetro del circulo ingresado es: "+ Circulo.perimetro(radio));

        System.out.println(lb.getTitulo());
        System.out.println(lb.getAutor());
        System.out.println(lb.getAño_publicacion());

        System.out.println("Ingrese el ancho del rectangulo: ");
        R.setAncho(sc.nextDouble());
        System.out.println("Ingrese el largo del rectangulo: ");
        R.setLargo(sc.nextDouble());

        System.out.println("El area del rectangulo es: "+ Math.round(R.area(R.getLargo(),R.getAncho())));
        System.out.println("El perimetro del rectangulo es: "+Math.round((R.perimetro(R.getLargo(),R.getAncho()))));

        System.out.println("Ingrese la velocidad del auto: ");
        int velocidad = sc.nextInt();
        auto.acelerar(velocidad);
        System.out.println("Ingrese el decremento de velocidad: ");
        int decremento = sc.nextInt();
        auto.frenar(decremento);

        System.out.println("Pelicula: " + P.getTitulo()+ "\n" + "Director: " + P.getDirector() + "\n" + "Duracion en minutos: " + P.getMinutos());


        System.out.println("Bienvenido al Banco Santander");
        while (true){
            System.out.println("1. Sacar plata");
            System.out.println("2. Ingresar plata");
            System.out.println("3. Salir");

            int opcion = sc.nextInt();

            switch (opcion){
                case 1:
                    System.out.print("Ingrese cuanta plata quiere sacar: ");
                    double extraer_saldo = sc.nextDouble();
                    if (CB.getSaldo() < extraer_saldo) {
                        System.out.println("No tiene suficiente dinero");
                    } else{
                        CB.setSaldo(CB.getSaldo() - extraer_saldo);
                        System.out.println("Su saldo actual es de "+CB.getSaldo());
                    }
                    break;
                case 2:
                    System.out.print("Ingrese cuanta plata quiere ingresar: ");
                    double ingresar_saldo = sc.nextDouble();
                    CB.setSaldo(CB.getSaldo() + ingresar_saldo);
                    System.out.println("Su saldo actual es de "+CB.getSaldo());
                    break;
                case 3:
                    System.out.println("Gracias por usar nuestro serivicio cliente N°"+CB.getNrocuenta());
                    System.exit(0);
            }
        }

    }
}
