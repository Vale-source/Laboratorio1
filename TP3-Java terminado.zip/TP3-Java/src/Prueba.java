import java.util.Scanner;
public class Prueba {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el divisor: ");
        double num9 = sc.nextInt();
        System.out.print("Ingrese el dividendo: ");
        double num10 = sc.nextInt();

        if (num10 == 0){
            System.out.println("No se puede dividir por 0");
        } else {
            System.out.println("El resultado de la division es: "+(num9/num10));
        }

    }
}
