import java.text.DecimalFormat;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //Ejercicio 1
        System.out.print("Ingrese un numero: ");
        int num = sc.nextInt();

        if (num % 2 == 0){
            System.out.println("Es par");
        } else {
            System.out.println("Es impar");
        }

        //Ejercicio 2
        System.out.print("Ingrese un numero: ");
        int num0 = sc.nextInt();

        if (num0 % 10 == 0){
            System.out.println("Es multiplo de 10");
        } else {
            System.out.println("No es multiplo de 10");
        }

        //Ejercicio 3
        System.out.print("Ingrese una letra: ");
        char letra = sc.next().charAt(0);

        if (letra == Character.toUpperCase(letra)){
            System.out.println("La letra ingresada es una mayuscula");
        } else {
            System.out.println("La letra ingresada no es minuscula");
        }

        //Ejercicio 4
        System.out.print("Ingrese el primer numero: ");
        float num1 = sc.nextFloat();
        System.out.print("Ingrese el segundo numero: ");
        float num2 = sc.nextFloat();

        if (num1 == num2){
            System.out.println(num1+" = "+num2);
        } else {
            System.out.println(num1+" ≠ "+num2);
        }

        //Ejercicio 5
        System.out.print("Ingrese un numero: ");
        float num3 = sc.nextFloat();
        System.out.print("Ingrese otro numero: ");
        float num4 = sc.nextFloat();

        if (num3 > num4){
            System.out.println("El numero mas grande es: "+num3);
        } else if (num4 > num3) {
            System.out.println("El numero mas grande es: "+num4);
        } else {
            System.out.println("Son numeros iguales");
        }

        //Ejercicio 6
        System.out.print("Ingrese un numero: ");
        int num5 = sc.nextInt();
        System.out.print("Ingrese otro numero: ");
        int num6 = sc.nextInt();

        if ((num5 % 10) == (num6 % 10)){
            System.out.println("Las ultimas cifras de ambos numeros son iguales");
        } else {
            System.out.println("Las ultimas cifras de ambos numeros no son iguales");
        }

        //Ejercicio 7
        System.out.print("Ingrese un numero: ");
        int num7 = sc.nextInt();

        if ((num7 % 3 == 0) && (num7 % 5 == 0)){
            System.out.println("El numero ingresado es multiplo de 3 y de 5");
        } else {
            System.out.println("El numero ingresado no es multiplo de 3 y de 5");
        }

        //Ejercicio 8
        System.out.print("Ingrese un numero: ");
        int num8 = sc.nextInt();

        if ((num8 % 2 == 0) && (num8 % 3 != 0)) {
            System.out.println("El numero ingresado es multiplo de 2");
        } else if ((num8 % 2 != 0) && (num8 % 3 == 0)) {
            System.out.println("El numero ingresado es multiplo de 3");
        } else if ((num8 % 6 == 0)){
            System.out.println("El numero ingresado es multiplo de 2 y de 3");
        } else {
            System.out.println("El numero ingresado no es multiplo ni de 2 o de 3");
        }

        //Ejercicio 9
        System.out.print("Ingrese una letra: ");
        char letra1 = sc.next().charAt(0);
        System.out.print("Ingrese otra letra: ");
        char letra2 = sc.next().charAt(0);

        if (letra1 == letra2){
            System.out.println("Ambas letras son iguales");
        } else {
            System.out.println("Las letras son distintas");
        }

        //Ejercicio 10
        System.out.print("Ingrese una letra: ");
        char letra3 = sc.next().charAt(0);
        System.out.print("Ingrese otra letra: ");
        char letra4 = sc.next().charAt(0);

        if (letra3 == Character.toLowerCase(letra3) && (letra4 == Character.toLowerCase(letra4))){
            System.out.println("Ambas letras son minusculas");
        } else {
            System.out.println("Las dos letras no son minusculas o alguna de ellas no es minusculas");
        }

        //Ejercicio 11
        System.out.print("Ingrese un caracter: ");
        char caracter = sc.next().charAt(0);

        if (Character.isDigit(caracter)){
            if (caracter >= '0' && caracter <= '9'){
                System.out.println("Es un digito numerico entre 0 y 9");
            } else {
                System.out.println("No esta entre 0 y 9");
            }
        } else {
            System.out.println("El valor ingresado no es un digito numerico");
        }

        //Ejercicio 12
        System.out.print("Ingrese el divisor: ");
        double num9 = sc.nextInt();
        System.out.print("Ingrese el dividendo: ");
        double num10 = sc.nextInt();

        if (num10 == 0){
            System.out.println("No se puede dividir por 0");
        } else {
            System.out.println("El resultado de la division es: "+(num9/num10));
        }

        //Ejercicio 13
        System.out.print("Ingrese el año biciesto: ");
        int year = sc.nextInt();

        if (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0)){
            System.out.println("Es año biciesto");
        } else {
            System.out.println("No es año biciesto");
        }

        //Ejercicio 14
        System.out.print("Ingrese un numero entero de tres cifras: ");
        int num11 = sc.nextInt();
        String num11_longitud_cadena = Integer.toString(num11);
        int num11_longitud_numero = num11_longitud_cadena.length();

        if (num11_longitud_numero == 3){
            int num11_digito_1 = num11/100;
            int num11_digito_2 = num11%10;
            if (num11_digito_1 == num11_digito_2){
                System.out.println(num11 + " es un numero capicua");
            } else {
                System.out.println(num11 + "no es un numero capicua");
            }
        } else {
            System.out.println("El numero ingresado no tiene 3 cifras");
        }

        //Ejercicio 15
        System.out.print("Ingrese la hora: ");
        int hora = sc.nextInt();
        System.out.print("Ingrese los minutos: ");
        int minutos = sc.nextInt();
        System.out.print("Ingrese los segundos: ");
        int segundos = sc.nextInt();

        if ((hora <= 24 && hora >= 0) && (minutos <= 59 && minutos >= 0) && (segundos <= 59 && segundos >= 0)){
            System.out.print("Hora valida");
        } else {
            System.out.print("Hora no valida");
        }

        //Ejercicio 16
        System.out.print("Ingrese el numero de un mes: ");
        int mes = sc.nextInt();

        if (mes < 1 || mes > 12){
            System.out.println("Ingrese un numero igual o mayor a 1 y menor o igual a 12");
        } else {
            switch (mes){
                case 1:
                    System.out.println("Enero; 31 dias");
                    break;
                case 2:
                    System.out.println("Febrero; 28 dias");
                    break;
                case 3:
                    System.out.println("Marzo; 31 dias");
                    break;
                case 4:
                    System.out.println("Abril; 30 dias");
                    break;
                case 5:
                    System.out.println("Mayo; 31 dias");
                    break;
                case 6:
                    System.out.println("Junio; 30 dias");
                    break;
                case 7:
                    System.out.println("Julio; 31 dias");
                    break;
                case 8:
                    System.out.println("Agosto; 31 dias");
                    break;
                case 9:
                    System.out.println("Septiembre; 30 dias");
                    break;
                case 10:
                    System.out.println("Octubre; 31 dias");
                    break;
                case 11:
                    System.out.println("Noviembre; 30 dias");
                    break;
                case 12:
                    System.out.println("Diciembre; 31 dias");
                    break;
            }
        }

        //Ejercicio 17
        System.out.print("Ingrese una calificacion: ");
        double calificacion = sc.nextDouble();

        if (calificacion >= 0 && calificacion < 5){
            System.out.println("Insuficiente");
        } else if (calificacion >= 5 && calificacion < 6){
            System.out.println("Suficiente");
        } else if (calificacion >= 6 && calificacion < 7){
            System.out.println("Bien");
        } else if (calificacion >= 7 && calificacion < 9){
            System.out.println("Notable");
        } else if (calificacion >= 9 && calificacion <= 10) {
            System.out.println("Sobresaliente");
        } else {
            System.out.println("Ingrese una nota entre 0 y 10");
        }

        //Ejercicio 18
        int num12 = 1;
        while (num12 <= 100){
            System.out.println(num12++);
        }

        //Ejercicio 19
        int num13 = 1;
        do {
            System.out.println(num13++);
        } while (num13 < 101);

        //Ejercicio 20
        for (int num14 = 1; num14 <= 100; num14++){
            System.out.println(num14);
        }

        //Ejercicio 21
        int num15 = 100;
        while (num15 >= 1){
            System.out.println(num15--);
        }

        //Ejercicio 22
        int num16 = 100;
        do {
            System.out.println(num16--);
        } while (num16 > 0);

        //Ejercicio 23
        for (int num17 = 100; num17 >= 1; num17--){
            System.out.println(num17);
        }

        //Ejercicio 24
        System.out.print("Resolucion con el bucle for: ");
        int condicion = 1;
        for (int num18 = sc.nextInt() ; condicion <= num18; condicion++){
            System.out.println(condicion);
        }

        System.out.print("Resolucion con el bucle while: ");
        int condicion_2 = 1;
        int num19 = sc.nextInt();
        while (condicion_2 <= num19){
            System.out.println(condicion_2++);
        }

        System.out.print("Resolucion con el bucle do while: ");
        int condicion_3 = 1;
        int num20 = sc.nextInt();
        do {
            System.out.println(condicion_3++);
        } while (num20 >= condicion_3);

        //Ejercicio 25
        System.out.print("Resolucion con el bucle for: ");
        for (int num21 = sc.nextInt() ; num21 >= 1; num21--){
            System.out.println(num21);
        }
        System.out.print("Resolucion con el bucle while: ");
        int num21 = sc.nextInt();
        while (num21 >= 1){
            System.out.println(num21--);
        }
        System.out.print("Resolucion con el bucle do while: ");
        int num22 = sc.nextInt();
        do {
            System.out.println(num22--);
        } while (num22 >= 1);

        //Ejercicio 26
        boolean auxiliar = true;
        do {
            System.out.print("Ingrese el primer numero: ");
            int num23 = sc.nextInt();
            System.out.print("Ingrese el segundo numero: ");
            int num24 = sc.nextInt();
            if (num23 == num24){
                System.out.println("Ambos numeros son iguales, ingrese nuevos valores");
                auxiliar = false;
            } else if (num23 < num24) {
                while (num23 <= num24) {
                    System.out.println(num23++);
                    auxiliar = true;
                }
            } else if (num24 < num23){
                while (num24 <= num23){
                    System.out.println(num24++);
                    auxiliar = true;
                }
            }
        } while (auxiliar != true);

        //Ejercicio 27
        boolean auxiliar_1 = true;
        do {
            System.out.print("Ingrese el primer numero: ");
            int num_A = sc.nextInt();
            System.out.print("Ingrese el segundo numero: ");
            int num_B = sc.nextInt();
            if (num_B < num_A){
                System.out.println("El primer valor debe ser menor al segundo");
                auxiliar_1 = false;
            } else {
                while (num_A <= num_B){
                    if (num_A % 2 == 0){
                        System.out.println(num_A++);
                        auxiliar_1 = true;
                    } else {
                        num_A++;
                    }
                }
            }
        } while (auxiliar_1 != true);

        //Ejercicio 28
        boolean auxiliar_2 = true;
        do {
            System.out.print("Ingrese el multiplo que desea buscar: ");
            int num_N = sc.nextInt();
            System.out.print("Ingrese el numero limite: ");
            int num_M = sc.nextInt();
            if (num_N < num_M) {
                for (int i = 1; i <= num_M; i++) {
                    if (i % num_N == 0) {
                        System.out.println(i);
                    }
                    auxiliar_2 = true;
                }
            } else {
                System.out.println("Ingrese de vuelta los datos");
                auxiliar_2 = false;
            }
        } while (auxiliar_2 != true);

        //Ejercicio 29
        boolean auxiliar_3 = true;
        String patron = "#.00";
        DecimalFormat formato = new DecimalFormat(patron);
        do {
            System.out.print("Ingrese las millas: ");
            double millas = sc.nextDouble();
            double km = millas * 1.6093;
            System.out.println("El equivalente en Kilometros es: "+formato.format(km));
            if (millas == 0){
                auxiliar_3 = false;
            }
        } while (auxiliar_3 == true);
    }
}
