package Ejercicio3;

import Ejercicio3.Clases.Factura;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Factura f = new Factura();
        Scanner sc = new Scanner(System.in);

        while (true){
            System.out.println("1. Agregar productos");
            System.out.println("2. Ver IVA");
            System.out.println("3. Modificar IVA");
            System.out.println("4. Total a pagar");
            System.out.println("5. Salir");
            System.out.println("Ingrese una opcion:");
            String eleccion = sc.next();

            switch (eleccion){
                case "1" -> {
                    f.articulo_precio();
                }
                case "2" -> {
                    System.out.println("El porcentaje actual del IVA es del %"+f.getIVA()*100);
                }
                case "3" -> {
                    System.out.print("Ingrese de cuanto quiere que sea el IVA: ");
                    double mod_iva = sc.nextDouble();
                    f.setIVA(mod_iva/100);
                }
                case "4" -> {
                    System.out.print("El total a pagar es de: ");
                    Double total = f.calculo_total(f.calculo_subtotal(),f.calculo_IVA(f.calculo_subtotal()));
                    System.out.println("El total a pagae es de $"+total);
                }
                case "5" -> {
                    System.out.println("Hasta luego");
                }
                default -> {
                    System.out.println("Ingrese una opcion valida");
                }

            }
            if (eleccion.equals("4")){
                break;
            }
        }
    }
}
