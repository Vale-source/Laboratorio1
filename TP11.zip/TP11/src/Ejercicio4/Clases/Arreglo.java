package Ejercicio4.Clases;

import java.util.ArrayList;
import java.util.Collections;


public class Arreglo {

    private ArrayList<Integer> numeros;

    public Arreglo() {

        this.numeros = new ArrayList<>();

    }

    public static Integer Max_list(ArrayList<Integer> numeros){
        ArrayList<Integer> nueva_lista = new ArrayList<>(numeros);
        nueva_lista.sort(Collections.reverseOrder());
        Integer max_num = nueva_lista.get(0);
        return max_num;
    }

    public static Integer Min_list(ArrayList<Integer> numeros){
        ArrayList<Integer> nueva_lista = new ArrayList<>(numeros);
        Collections.sort(nueva_lista);
        Integer min_num = nueva_lista.get(0);
        return min_num;
    }

    public void Rango(Integer numeromax, Integer numeromin){
        for (int i = numeromin; i <= numeromax; i++) {
            System.out.print(i + " ");
        }
    }

    public ArrayList<Integer> getNumeros() {
        return numeros;
    }

    public void setNumeros(ArrayList<Integer> numeros) {
        this.numeros = numeros;
    }
}
