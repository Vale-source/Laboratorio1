package Ejercicio4;

import Ejercicio4.Clases.Arreglo;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Arreglo arreglo_num = new Arreglo();
        ArrayList<Integer> lista_main = new ArrayList<>();

        Llenar_lista(lista_main);

        arreglo_num.setNumeros(lista_main);
        System.out.println("La lista de numeros es: ");
        System.out.println(arreglo_num.getNumeros());
        System.out.print("El elemento mas grande en la lista es: ");
        Integer max = arreglo_num.Max_list(lista_main);
        System.out.println(max);
        System.out.print("El elemento mas pequeño en la lista es: ");
        Integer min = arreglo_num.Min_list(lista_main);
        System.out.println(min);
        System.out.println("Rango de numeros entre "+max+" y "+min+": ");
        arreglo_num.Rango(max,min);
    }

    public static ArrayList<Integer> Llenar_lista(ArrayList<Integer> lista_main){
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < 5; i++) {
            System.out.print("Ingrese el el numero en la posicion "+(i+1)+": ");
            Integer num = sc.nextInt();
            lista_main.add(num);
        }
        return lista_main;
    }
}
