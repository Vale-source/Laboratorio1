package Ejercicio5.Clases;

import java.util.ArrayList;
import java.util.Random;

public class Numeros_random {

    private ArrayList<Integer> random;

    private Integer count;

    private Double prom;
    public Numeros_random(){

        this.random = new ArrayList<>();
        count = 0;
        prom = 0.0;
    }

    public void Llenar_arreglo(){
        Random ran = new Random();
        for (int i = 0; i < 20; i++) {
            Integer num = ran.nextInt(101);
            if (num % 2 == 0){
                random.add(num);
                count++;
            } else {
                i--;
            }
        }

        System.out.println(random);

    }

    public Double Promedio(){
        Double suma = 0.0;
        for (Integer num: random) {
            suma += num;
        }
        prom = suma/count;

        return prom;
    }

    public void Valores(){
        int count_equals = 0;
        int count_major = 0;
        int count_minimum = 0;
        for (int i = 0; i < 20; i++) {
            if (random.get(i).doubleValue() == Math.round(prom)){
                count_equals++;
            } else if (random.get(i).doubleValue() > prom) {
                count_major++;
            } else if (random.get(i).doubleValue() < prom) {
                count_minimum++;
            }
        }

        System.out.print("Cantidad de numeros iguales al promedio: ");
        System.out.println(count_equals);

        System.out.print("Cantidad de numeros mayores al promedio: ");
        System.out.println(count_major);

        System.out.print("Cantidad de numeros menores al promedio: ");
        System.out.println(count_minimum);
    }
}
