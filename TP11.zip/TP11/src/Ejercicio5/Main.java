package Ejercicio5;

import Ejercicio5.Clases.Numeros_random;

public class Main {
    public static void main(String[] args) {
        Numeros_random nr = new Numeros_random();

        System.out.println("Los numeros generados son: ");
        nr.Llenar_arreglo();

        System.out.print("El promedio aritmetico es: ");
        System.out.println(nr.Promedio());
        System.out.print("El promedio aritmetico redondeado (se toma de referencia para comparar) es: ");
        System.out.println(Math.round(nr.Promedio()));

        nr.Valores();

    }
}
