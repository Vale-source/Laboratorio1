package Ejercicio3.Clases;

import java.util.ArrayList;
import java.util.Scanner;

public class Factura {
    private Integer nrofactura,cantidad;
    private String fecha, cliente;

    private Double subtotal,total;

    private double IVA;
    private ArrayList<String> articulos;
    private ArrayList<Double> precios;

    public Factura(){
        nrofactura = 0;
        fecha = "";
        cliente = "";
        this.articulos = new ArrayList<>();
        this.precios = new ArrayList<>();
        cantidad = 0;
        subtotal = 0.0;
        IVA = 0.21;
        total = 0.0;
    }

    public void articulo_precio(){
        Scanner sc = new Scanner(System.in);
        while (true){
            System.out.println("Pulse X para teminar");
            System.out.print("Ingrese el producto: ");
            String producto = sc.next();

            if (producto.equals("X") || producto.equals("x")){
                break;
            } else {
                articulos.add(producto);
                System.out.print("Ingrese el precio: ");
                Double precio = sc.nextDouble();
                precios.add(precio);
            }

            System.out.println();

        }
    }

    public Double calculo_subtotal(){
        Double suma = 0.0;
        for (Double t : precios) {
            suma += t;
        }
        return suma;
    }

    public Double calculo_IVA(Double suma){
        return IVA * suma;
    }

    public static Double calculo_total(Double suma, Double IVA){
        return suma+IVA;
    }

    public double getIVA() {
        return IVA;
    }

    public void setIVA(double IVA) {
        this.IVA = IVA;
    }
}
