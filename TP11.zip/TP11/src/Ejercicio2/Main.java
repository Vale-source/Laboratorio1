package Ejercicio2;

import Ejercicio2.Clases.EquipoDeFutbol;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        EquipoDeFutbol equipo = new EquipoDeFutbol();

        while (true){
            System.out.println("1. Ver plantel");
            System.out.println("2. Agregar jugador");
            System.out.println("3. Eliminar jugador");
            System.out.println("4. Salir");
            System.out.println("Ingrese una opcion:");
            String eleccion = sc.next();

            switch (eleccion){
                case "1" -> {
                    equipo.mostrar_jugadores();
                }
                case "2" -> {
                    equipo.agregar_jugador();
                }
                case "3" -> {
                    equipo.borrar_jugadores();
                }
                case "4" ->{
                    System.out.println("Hasta pronto");
                }
                default -> {
                    System.out.println("Ingrese una opcion valida");
                }
            }
            if (eleccion.equals("4")){
                break;
            }
        }
    }
}
