package Ejercicio2.Clases;
import java.util.Scanner;
import java.util.ArrayList;

public class EquipoDeFutbol {
     public ArrayList<String> plantel;

    public EquipoDeFutbol(){
        this.plantel = new ArrayList<>();
    }

    public void agregar_jugador(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese el nombre del jugador: ");
        String jugador = sc.next();
        plantel.add(jugador);
    }

    public void mostrar_jugadores(){
        for (String i: plantel) {
            System.out.println(i+" ");
        }
    }

    public void borrar_jugadores(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Ingrese el nombre del jugador a eliminar: ");
        String jugador_borrar = sc.next();
        if (plantel.contains(jugador_borrar)){
            plantel.remove(jugador_borrar);
            System.out.println("El jugador "+jugador_borrar+" fue eliminado de la lista");
        } else {
            System.out.println("El jugador no fue encontrado en la lista");
        }
    }

}
