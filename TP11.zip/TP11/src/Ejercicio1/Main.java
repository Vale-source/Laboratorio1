package Ejercicio1;

import java.util.ArrayList;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        ArrayList <String> marcas = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        boolean condicion = true;
        while (condicion == true) {
            System.out.println("Ingrese una marca de auto: ");
            String marca = sc.next();
            marcas.add(marca);
            System.out.println("¿Desea ingresar otra marca? S/N");
            String confirmacion = sc.next();
            confirmacion = confirmacion.toUpperCase();
            switch (confirmacion){
                case "S" -> {}
                case "N" -> {
                    System.out.println("Lista de autos ingresadas: ");
                    for (String lista : marcas) {
                        System.out.println(lista);
                    }
                }
                default -> {
                    System.out.println("Ingrese una letra valida");
                }
            }
            if (confirmacion.equals("N")) {
                break;
            }
        }
    }
}