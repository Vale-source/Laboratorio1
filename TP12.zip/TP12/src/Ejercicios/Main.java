package Ejercicios;
import java.util.ArrayList;
import java.util.regex.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //Ejercicio 1
        String palabra = "cadena";

        if (!palabra.matches(".*\\d$")){
            System.out.println("La palabra no termina con digito");
        } else {
            System.out.println("La palabra termina con digito");
        }

        //Ejercicio 2

        if (!palabra.matches("^\\d.*")){
            System.out.println("La palabra no empieza con digito");
        } else {
            System.out.println("La palabra empieza con digito");
        }

        //Ejercicio 3

        if (!palabra.matches("^\\w{5,10}[:alpha:]$")) {
            System.out.println("La palabra no está formado por un mínimo de 5 letras mayúsculas o minúsculas y un máximo de 10");
        } else {
            System.out.println("La palabra está formado por un mínimo de 5 letras mayúsculas o minúsculas y un máximo de 10.");
        }

        //Ejercicio 4
        String DNI = "44-771-675";

        if (!DNI.matches("^\\d{2}-\\d{3}-\\d{3}$")) {
            System.out.println("No es un DNI");
        } else {
            System.out.println("Si es un DNI");
        }

        //Ejercicio 5
        ArrayList<String> Emails = new ArrayList<>();
        System.out.print("Ingrese un correo electronico: ");
        String mail = sc.next();
        Pattern MailPattern = Pattern.compile("^[a-zA-Z0-9._%+-]+@[a-zA-Z.-]+\\.[a-zA-Z]{2,}$");
        Matcher MailMatcher = MailPattern.matcher(mail);

        if (MailMatcher.matches()){
            Emails.add(mail);
            System.out.println("Correo agregado correctamente");
        } else {
            System.out.println("No es un correo");
        }

        //Ejercicio 6

        if (!palabra.matches(".*abc.*")){
            System.out.println("La palabra no contiene la cadena abc ");
        } else {
            System.out.println("La palabra si contiene la cadena abc");
        }
    }
}













































































