package Ejemplos_validacion_de_datos;

import java.util.ArrayList;
import java.util.regex.*;
public class Main {
    public static void main(String[] args) {
        ArrayList<String> datos = new ArrayList<>();
        datos.add("valentincuriel03@gmail.com");
        datos.add("20/06/2023");
        datos.add("2604114895");
        Pattern patronEmail = Pattern.compile("^[a-zA-Z0-9._%+-]+@[a-zA-Z.-]+\\.[a-zA-Z]{2,}$");
        Pattern patronFecha = Pattern.compile("\\d{2}/\\d{2}/\\d{4}");
        Pattern patronTel = Pattern.compile("^\\d{10}$");

        for (String dato : datos) {
            Matcher matcher = patronEmail.matcher(dato);
            Matcher matcher1 = patronFecha.matcher(dato);
            Matcher matcher2 = patronTel.matcher(dato);

            if (matcher.find()) {
                System.out.println("Correo: " + matcher.group());
            }

            if (matcher1.find()) {
                System.out.println("Texto coincidente con la fecha: " + matcher1.group());
            }

            if (matcher2.find()){
                System.out.println("Numero de telefono: " + matcher2.group());
            }
        }
    }
}